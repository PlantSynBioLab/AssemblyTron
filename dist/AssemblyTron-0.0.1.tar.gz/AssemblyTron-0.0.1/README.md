# AssemblyTron

This is a package to automate DNA assembly builds with the Opentron OT-2 liquid handling robot. You can use
[Github-flavored Markdown](https://guides.github.com/PlantSynBioLab/opentrons)
to access the working repository.