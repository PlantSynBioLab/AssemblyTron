# DNA-AssemblyLine

This is a package to automate the opetrons liquid handling robot. You can use
[Github-flavored Markdown](https://guides.github.com/PlantSynBioLab/opentrons)
to access it.